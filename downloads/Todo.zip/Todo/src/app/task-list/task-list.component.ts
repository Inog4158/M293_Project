import { Component } from '@angular/core';
import {DataService} from "../data.service";

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent {
  public hoveredIndex: number | null = null;
  public hoveredIndexT: number | null = null;

  constructor(protected service: DataService) {

  }

  clearFinished(): void {
    this.service.finished = [];
  }

  mouseOverFinished(index: number) {
    this.hoveredIndex = index;
  }

  mouseOutFinished() {
    this.hoveredIndex = null;
  }
  mouseOverTodos(index: number) {
    this.hoveredIndexT = index;
  }

  mouseOutTodos() {
    this.hoveredIndexT = null;
  }

  resetIndex(): void {
    this.hoveredIndex = null;
    this.hoveredIndexT = null;
  }
}
