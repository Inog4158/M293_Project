import {Component} from '@angular/core';
import {Router} from "@angular/router";
import {Task} from "../task";
import {DataService} from "../data.service";

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrl: './add-task.component.css'
})
export class AddTaskComponent {
  newTask: Task = {
    id: 0,
    title: '',
    description: '',
    date: new Date(),
    finished: null
  };

  constructor(private router: Router, protected service: DataService) { }

  createTask(): void {
    if (this.newTask.title === "" || this.newTask.description === "" || this.newTask.date == undefined) {
      return;
    }
    this.service.todos.push({id: this.getNewId(), title: this.newTask.title, description: this.newTask.description, date: this.newTask.date} as Task);
    this.router.navigate(['/overview']);
  }

  getNewId(): number {
    const combined: Task[] = [ ...this.service.todos, ...this.service.finished];
    let highestId: number = 0;
    for (let task of combined) {
      if (task.id > highestId){
        highestId = task.id;
      }
    }
    return highestId+1;
  }
}
