import { Task } from './task';

export const TASKS: Task[] = [
  { id: 12, title: 'Dr. Nice', description: 'beschreibung bla bla', date: new Date(), finished: null},
  { id: 13, title: 'Bombasto', description: 'beschreibung bla bla', date: new Date(), finished: null},
  { id: 14, title: 'Celeritas', description: 'beschreibung bla bla', date: new Date(), finished: null},
  { id: 15, title: 'Magneta', description: 'beschreibung bla bla', date: new Date(), finished: null },
  { id: 16, title: 'RubberMan', description: 'beschreibung bla bla', date: new Date(), finished: null },
  { id: 17, title: 'Dynama', description: 'beschreibung bla bla', date: new Date(), finished: null },
  { id: 18, title: 'Dr. IQ', description: 'beschreibung bla bla', date: new Date(), finished: null },
  { id: 19, title: 'Magma', description: 'beschreibung bla bla', date: new Date(), finished: null },
  { id: 20, title: 'Tornado', description: 'beschreibung bla bla', date: new Date(), finished: null }
];
