import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AddTaskComponent} from "./add-task/add-task.component";
import {TaskListComponent} from "./task-list/task-list.component";
import {TaskDetailComponent} from "./task-detail/task-detail.component";

const routes: Routes = [
  { path: '', redirectTo: '/overview', pathMatch: 'full' },
  {path: 'add', component: AddTaskComponent },
  {path: 'overview', component: TaskListComponent},
  {path: 'detail/:id', component: TaskDetailComponent },
  {path: '**', redirectTo: '/overview', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
