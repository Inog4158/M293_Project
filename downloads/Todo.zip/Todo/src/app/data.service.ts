import { Injectable } from '@angular/core';
import {Task} from "./task";
import {TASKS} from "./mock-tasks";
import {Observable, of} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public todos: Task[] = TASKS.slice();
  public finished: Task[] = new Array<Task>();

  constructor() {

  }



  searchTask(term: string): Observable<Task[]> {
    term = term.trim();
    if (!term) {
      return of([]);
    }
    console.log(typeof this.todos[0].date);
    const matchedTasks = this.todos.filter(task =>
      Object.values(task).some(value => {
        if (typeof value === 'string' || typeof value === 'number') {
          return value.toString().toLowerCase().includes(term.toLowerCase());
        } else if (value instanceof Date) {
          return value.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit' }).toString().toLowerCase().includes(term.toLowerCase());
        } else {
          return false;
        }
      })
    );

    const uniqueTasks = matchedTasks.filter((task, index, self) =>
        index === self.findIndex((t) =>
          Object.values(t).every((value, i) =>
            value === Object.values(task)[i]
          )
        )
    );

    return of(uniqueTasks);
  }
}
