import {Component, Input} from '@angular/core';
import {Task} from "../task";

@Component({
  selector: 'app-todo-item',
  templateUrl: './todo-item.component.html',
  styleUrl: './todo-item.component.css'
})
export class TodoItemComponent {
  @Input() task!: Task;
  @Input() status!: string;
}
