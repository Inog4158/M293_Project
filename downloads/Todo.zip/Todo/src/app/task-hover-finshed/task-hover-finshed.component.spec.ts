import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskHoverFinshedComponent } from './task-hover-finshed.component';

describe('TaskHoverFinshedComponent', () => {
  let component: TaskHoverFinshedComponent;
  let fixture: ComponentFixture<TaskHoverFinshedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TaskHoverFinshedComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TaskHoverFinshedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
