import {Component, Input} from '@angular/core';
import {Task} from "../task";
import {DataService} from "../data.service";

@Component({
  selector: 'app-task-hover-finshed',
  templateUrl: './task-hover-finshed.component.html',
  styleUrl: './task-hover-finshed.component.css'
})
export class TaskHoverFinshedComponent {
  constructor(protected service: DataService) {}

  @Input() task!: Task;
  delete(): void{
    const index: number = this.service.finished.indexOf(this.task);
    this.service.finished.splice(index, 1)
  }
  redo(): void{
    this.task.date = this.task.finished!;
    this.service.todos.push(this.task);
    this.delete();
  }
}
