import {Component, Input} from '@angular/core';
import {DataService} from "../data.service";
import {Task} from "../task";

@Component({
  selector: 'app-task-hover-todos',
  templateUrl: './task-hover-todos.component.html',
  styleUrl: './task-hover-todos.component.css'
})
export class TaskHoverTodosComponent {
  constructor(protected service: DataService) {}

  @Input() task!: Task;
  delete(): void{
    const index: number = this.service.todos.indexOf(this.task);
    this.service.todos.splice(index, 1)
  }
  finish(): void{
    this.task.finished = this.task.date;
    this.task.date = new Date();
    this.service.finished.push(this.task);
    this.delete();
  }
}
