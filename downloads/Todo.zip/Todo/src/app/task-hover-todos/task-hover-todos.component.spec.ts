import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskHoverTodosComponent } from './task-hover-todos.component';

describe('TaskHoverTodosComponent', () => {
  let component: TaskHoverTodosComponent;
  let fixture: ComponentFixture<TaskHoverTodosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TaskHoverTodosComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TaskHoverTodosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
