import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TaskListComponent } from './task-list/task-list.component';
import { TodoItemComponent } from './todo-item/todo-item.component';
import { SearchComponent } from './search/search.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { TaskDetailComponent } from './task-detail/task-detail.component';
import {FormsModule} from "@angular/forms";
import { TaskHoverFinshedComponent } from './task-hover-finshed/task-hover-finshed.component';
import { TaskHoverTodosComponent } from './task-hover-todos/task-hover-todos.component';



@NgModule({
  declarations: [
    AppComponent,
    TaskListComponent,
    TodoItemComponent,
    SearchComponent,
    AddTaskComponent,
    TaskDetailComponent,
    TaskHoverFinshedComponent,
    TaskHoverTodosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
