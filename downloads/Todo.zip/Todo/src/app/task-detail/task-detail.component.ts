import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService} from "../data.service";
import { Task} from "../task";

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrls: ['./task-detail.component.css']
})
export class TaskDetailComponent {
  task: Task;
  id: string |null;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: DataService
  ) {
    this.id =  this.route.snapshot.paramMap.get('id');
    this.task = Object.assign({}, this.getTaskById());
  }


  getTaskById(): Task {
    const combined: Task[] = [ ...this.service.todos, ...this.service.finished];
    for (let task of combined) {
      if (task.id.toString() === this.id){
        return task;
      }
    }
    return combined[0];
  }

  saveTask(): void {
    this.updateTask(this.task);
    this.goBack();
  }

  goBack(): void {
    this.router.navigate(['/overview']);
  }

  updateTask(updatedTask: Task): void {
    for (let task of this.service.todos) {
      if (task.id.toString() === this.id){
        const index = this.service.todos.indexOf(task);
        this.service.todos[index] = updatedTask;
      }
    }
    for (let task of this.service.finished) {
      if (task.id.toString() === this.id){
        const index = this.service.finished.indexOf(task);
        this.service.finished[index] = updatedTask;
      }
    }
  }
}
