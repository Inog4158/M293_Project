#ifndef EXTERNE_FUNKTIONEN_H
#define EXTERNE_FUNKTIONEN_H

#include "src/Adafruit_NeoPixel/Adafruit_NeoPixel.h"

void Edisplay(Adafruit_NeoPixel rows[]);
void EresetDisplay(Adafruit_NeoPixel rows[]);
int EswitchLetterColor(int zeichen, int color);
bool EcountTicks(int counter, int sizeofString, int duration);
byte EreadLetterByte(int index1, int index2);
int EtranslateSector(int scroll, int sektor);
void EbuchstabePlatzieren(int zeichen, int scroll, int scrollRow, int sektor, int color, Adafruit_NeoPixel rows[]);
int EtranslateText(unsigned char textChar);
void EchangeBrightness(int percent, Adafruit_NeoPixel rows[]);

#endif