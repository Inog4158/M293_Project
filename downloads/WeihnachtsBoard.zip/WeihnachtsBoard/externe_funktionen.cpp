#include "externe_funktionen.h"
#include "letters_array.h"

int EswitchLetterColor(int zeichen, int color)
{
    switch (zeichen)
    {
    case 32: //@
        return 7;
        break;
    case 7: //'
        return 1;
        break;
    case 92: //|
        return 3;
        break;
    case 6: //|
        return 7;
        break;
    default:
        return color;
        break;
    }
}

void Edisplay(Adafruit_NeoPixel rows[])
{
    for (int i = 0; i <= 5; i++)
    {
        rows[i].show();
    }
}

void EresetDisplay(Adafruit_NeoPixel rows[])
{
    for (int i = 0; i <= 5; i++)
    {
        rows[i].clear();
        rows[i].show();
    }
}



bool EcountTicks(int counter, int sizeofString, int duration)
{
    if (counter >= duration*50)
    {
        return true;
    }
    else
    {
        return false;
    }
}

byte EreadLetterByte(int index1, int index2)
{
    return pgm_read_byte(&letters[index1][index2]);
}

int EtranslateSector(int scroll, int sektor)
{
    return (sektor * 7 + scroll);
}

void EbuchstabePlatzieren(int zeichen, int scroll, int scrollRow, int sektor, int color, Adafruit_NeoPixel rows[])
{
    int tmpColor = color;
    color = EswitchLetterColor(zeichen, color);
    for (int row = 0; row <= 5; row++)
    {
        if (row + scrollRow <= 5 && row + scrollRow >= 0)
        {
            byte currentRowFromLetter = EreadLetterByte(zeichen, row);
            int pixelPosition = 0;
            for (int bitzaehler = 16; bitzaehler >= 1; bitzaehler /= 2, pixelPosition++)
            {
                if (currentRowFromLetter == (currentRowFromLetter | bitzaehler))
                {
                    rows[row + scrollRow].setPixelColor(pixelPosition + EtranslateSector(scroll, sektor), rows[row + scrollRow].Color(colorlist[color][0], colorlist[color][1], colorlist[color][2]));
                }
            }
        }
    }
    color = tmpColor;
}

int EtranslateText(unsigned char textChar)
{

    switch (textChar)
    {
        case 129:
            return 95;
            break;
        case 132:
            return 96;
            break;
        case 142:
            return 97;
            break;
        case 148:
            return 98;
            break;
        case 153:
            return 99;
            break;
        case 154:
            return 100;
            break;
        default:
            if (textChar >= 32)
            {
                return textChar - 32;
            }
            break;
        }
}

void EchangeBrightness(int percent, Adafruit_NeoPixel rows[])
{
    for (int i = 0; i <= 5; i++)
    {
        rows[i].setBrightness(percent * 255 / 100);
    }
}