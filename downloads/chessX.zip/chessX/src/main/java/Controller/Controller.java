package Controller;

import Cells.Cell;
import Cells.CellBoard;
import Pieces.pieceBase;
import Pieces.pieceFirstMoveDependency;
import Pieces.pieceKing;
import Pieces.piecePawn;
import Server.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;

public class Controller implements Serializable {
    private byte[] byteData;
    private CellBoard cellHolderCopy;
    private ArrayList<pieceBase> pieceList;
    private pieceKing whiteKing;
    private pieceKing blackKing;
    private piecePawn pawn2Felder;
    private piecePawn pawnEnPassant;
    private CellBoard cellHolder;
    public pieceBase currentPiece;
    private boolean whiteTurn;
    private ScoreBoard scoreBoard;
    private SaveMoves saveMoves;
    private serverConnector server;
    private int rowBefore;
    private int colBefore;

    public Controller(CellBoard ch, boolean wt) {
        whiteTurn = wt;
        cellHolder = ch;
        scoreBoard = null;
        currentPiece = null;
        pieceList = new ArrayList<>();
        for (Cell cell : cellHolder.getCells()) {
            if (cell.hasPiece()) {
                pieceList.add(cell.getPiece());
            }
        }
        for (pieceBase piece : pieceList) {
            if (piece.getName().equals("king")) {
                if (piece.getIsWhite()) {
                    whiteKing = (pieceKing) piece;
                } else {
                    blackKing = (pieceKing) piece;
                }
            }
        }
        currentPiece = cellHolder.getMoveTest().getPiece();
    }

    public Controller(ScoreBoard SB, ArrayList<pieceBase> pl, CellBoard ch, pieceKing bK, pieceKing wK, String rootPath, ThreadGroup threadGroup) {
        pieceList = pl;
        scoreBoard = SB;
        cellHolder = ch;
        currentPiece = null;
        whiteTurn = true;
        blackKing = bK;
        whiteKing = wK;
        saveMoves = new SaveMoves(rootPath);
        server = new serverConnector(this, threadGroup);
        Thread t = new Thread(threadGroup, server);
        t.start();
    }

    /*@Override
    public void actionPerformed(ActionEvent e) {
        builddd();
    }

    public void builddd() {
        buildChessBoard = new buildChessBoard(pieceList); //bei einem button dann machen, sodass es nur ausgeführt wird wenn man den buton "restore" drückt und hald beim gegeneinander spielen.
        buildChessBoard.csvSplit();
        buildtheBoard();
    }

    public void buildtheBoard() {
        int row = 0;
        int col = 0;

        for (int i = 0; i < buildChessBoard.getRows().size(); i++) {
            row = buildChessBoard.getRows().get(i);
            col = buildChessBoard.getCols().get(i);

            String name = buildChessBoard.getNames().get(i);
            kaaa(name, row, col);

            //jedes mal ein anderes current piece
            //pressedButton(row, col);
        }
    }*/
    public void kaaa(String name, int row, int col) {
        for (pieceBase x : pieceList) {
            if (x.getName().equals(name)) {
                x.canMove();
                for (Cell c : x.getAllowedMoves()) {
                    if (c.getRow() == row && c.getCol() == col) {
                    }
                }
            }
        }
    }

    public void pressedButton(int row, int col) {
        if (currentPiece != null) {
            loadArrays();
            rowBefore = currentPiece.getCurrentCell().getRow();
            colBefore = currentPiece.getCurrentCell().getCol();
            specialMove(row, col);
            capture(row, col);
            move(row, col);
            checkForPawnEvolution();
            //gemachter move/specialM/capture speichern mit chess notation. Neue klasse erstellen, die das macht. Kann ich auch in all den 3 (4) moves machen
            if (isCheck()) {
                if (isCheckMate()) {
                    saveMoves.chessNotationMate();
                    server.uploadCheckmate(whiteTurn);
                    //System.exit(0);
                } else {
                    saveMoves.chessNotationChek();
                }
            }
            selectNewCurrentPiece(row, col);
        } else {
            selectNewCurrentPiece(row, col);
        }
        server.uploadController(this);
    }

    private void checkForPawnEvolution() {
        for (int r = 0; r < 8; r += 7) {
            for (int c = 0; c < 8; c++) {
                if (cellHolder.getCell(r, c).hasPiece()) {
                    if (cellHolder.getCell(r, c).getPiece().getName().equals("pawn")) {
                        piecePawn pawn = (piecePawn) cellHolder.getCell(r, c).getPiece();
                        pawn.checkEvolution();
                    }
                }
            }
        }
    }

    private void removePiece(pieceBase piece) {
        if (piece.getIsWhite()) {
            scoreBoard.addScoreBlack(piece.getValue());
        } else {
            scoreBoard.addScoreWhite(piece.getValue());
        }
        scoreBoard.updateScore();
        piece.getCurrentCell().setCurrentPiece(null);
        pieceList.remove(piece);
    }

    private void resetCurrentStuff() {
        if (currentPiece == null) {
            return;
        }
        cellHolder.clearSelections();
        currentPiece.clearMoves();
        currentPiece = null;
    }

    private void capture(int row, int col) {
        if (currentPiece == null) {
            return;
        }
        if (currentPiece.getAllowedCaptures().isEmpty()) {
            return;
        }
        for (Cell x : currentPiece.getAllowedCaptures()) {
            if (row == x.getRow() && col == x.getCol()) {
                pieceBase killedPiece = cellHolder.getCell(row, col).getPiece(pieceList);
                saveMoves.ChessNotation(row, col, currentPiece, killedPiece, false, pieceList, cellHolder, rowBefore, colBefore);
                removePiece(killedPiece);
                currentPiece.setCurrentCell(row, col);
                pawn2Felder = null;
                resetCurrentStuff();
                whiteTurn = !whiteTurn;
                return;
            }
        }
    }

    private void move(int row, int col) {
        if (currentPiece == null) {
            return;
        }
        if (currentPiece.getAllowedMoves().isEmpty()) {
            return;
        }
        for (Cell x : currentPiece.getAllowedMoves()) {
            if (row == x.getRow() && col == x.getCol()) {
                saveMoves.ChessNotation(row, col, currentPiece, null, false, pieceList, cellHolder, rowBefore, colBefore);
                currentPiece.setCurrentCell(row, col);
                pawn2Felder = null;
                resetCurrentStuff();
                whiteTurn = !whiteTurn;
                return;
            }
        }
    }

    private void specialMove(int row, int col) {
        if ((currentPiece == whiteKing || currentPiece == blackKing) && !((pieceFirstMoveDependency) currentPiece).getSpecialMoves().isEmpty()) {
            for (pieceBase piece : pieceList) {
                if (piece.getName().equals("rook") && !((pieceFirstMoveDependency) piece).getSpecialMoves().isEmpty()) {
                    Cell rookCell = ((pieceFirstMoveDependency) piece).getSpecialMoves().get(0);
                    if ((rookCell.getCol() == col-1 || rookCell.getCol() == col+1) && rookCell.getRow() == row) {
                        RochadeMove(rookCell.getRow(), rookCell.getCol(), piece);   // Moves Rook
                        break;
                    }
                }
            }
            RochadeMove(row, col, currentPiece); // Moves King
            resetCurrentStuff();



        } else if (currentPiece != null && currentPiece instanceof pieceFirstMoveDependency) {
            if (((pieceFirstMoveDependency) currentPiece).getSpecialMoves().isEmpty()) {
                return;
            }
            for (Cell x : ((pieceFirstMoveDependency) currentPiece).getSpecialMoves()) {
                if (row == x.getRow() && col == x.getCol()) {
                    saveMoves.ChessNotation(row, col, currentPiece, null, false, pieceList, cellHolder, rowBefore, colBefore);
                    currentPiece.setCurrentCell(row, col);
                    if (colBefore != col && pawn2Felder != null) { //das bedeutet, dass ein pawn schräg gefahren ist(en passant), das heisst er muss nun einen schlafgen(remove)
                        removePiece(pawn2Felder);
                    }
                    pawnMovedTwo(row); //den pawn der 2 felder nach vorne bewegt wurde speichern (nur falls es dieser Pawn special move war)
                    resetCurrentStuff();
                    whiteTurn = !whiteTurn;
                    return;
                }
            }
        }
    }

    public void pawnMovedTwo(int row) {
        if (currentPiece.getName().equals("pawn") && (row == 3 || row == 4)) {
            pawn2Felder = null;
            pawn2Felder = currentPiece.getCurrentCell().getPawn();
        } else {
            pawn2Felder = null;
        }
    }

    public void EnPassant() {
        if (currentPiece.getName().equals("pawn")) {
            pawnEnPassant = currentPiece.getCurrentCell().getPawn();
            pawnEnPassant.setEnPassant(currentPiece, pawn2Felder);
        }
    }

    private void RochadeMove(int row, int col, pieceBase piece) {
        for (Cell x : ((pieceFirstMoveDependency) piece).getSpecialMoves()) {
            if (row == x.getRow() && col == x.getCol()) {
                saveMoves.ChessNotation(row, col, currentPiece, null, true, pieceList, cellHolder, rowBefore, colBefore);
                piece.setCurrentCell(row, col);
                if (piece == whiteKing || piece == blackKing) {
                    whiteTurn = !whiteTurn;
                }
                return;
            }
        }
    }

    private void SetRochade() {
        if (currentPiece == whiteKing) {
            whiteKing.rochade();
        } else if (currentPiece == blackKing) {
            blackKing.rochade();
        }
    }


    private void selectNewCurrentPiece(int row, int col) {
        resetCurrentStuff();
        if (cellHolder.getCell(row, col).hasPiece() && cellHolder.getCell(row, col).getPiece(pieceList).getIsWhite() == whiteTurn) {
            currentPiece = cellHolder.getCell(row, col).getPiece(pieceList);
            currentPiece.getCurrentCell().setIsSelected(true);
            loadArrays();
        }
    }

    public CellBoard getCellHolder() {
        return cellHolder;
    }

    public ArrayList<pieceBase> getPieceList() {
        return pieceList;
    }

    public boolean isWhiteTurn() {
        return whiteTurn;
    }

    private void loadArrays() {
        currentPiece.canMove();
        SetRochade();
        EnPassant();
        if (currentPiece == null) {
            return;
        }
        currentPiece.setAllowedMoves(retestArrayList(currentPiece.getAllowedMoves()));
        currentPiece.setAllowedCaptures(retestArrayList(currentPiece.getAllowedCaptures()));
        if (currentPiece instanceof pieceFirstMoveDependency) {
            ((pieceFirstMoveDependency) currentPiece).setSpecialMoves(retestArrayList(((pieceFirstMoveDependency) currentPiece).getSpecialMoves()));
        }
    }

    public boolean tryMove(int row, int col) {
        if (currentPiece == null) {
            return true;
        }
        currentPiece.setCurrentCell(row, col);
        whiteTurn = !whiteTurn;
        //Diese linie überprüft ob der könig des Aktivenspieler jetzt in schach steht. Falls nicht ist der Zug erlaubt und gibt ein True zurück
        return !((!whiteTurn && whiteKing.checkForCheck(whiteKing.getCurrentCell().getRow(), whiteKing.getCurrentCell().getCol())) || (whiteTurn && blackKing.checkForCheck(blackKing.getCurrentCell().getRow(), blackKing.getCurrentCell().getCol())));
    }

    private void saveBackup() {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(cellHolder);
            oos.flush();
            oos.close();
            bos.close();
            byteData = bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadBackup() {
        ByteArrayInputStream bais = new ByteArrayInputStream(byteData);
        try {
            cellHolderCopy = (CellBoard) new ObjectInputStream(bais).readObject();
            bais.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private ArrayList<Cell> retestArrayList(ArrayList<Cell> list) {
        cellHolder.clearMoveTest();
        currentPiece.getCurrentCell().setMoveTest(true);
        saveBackup();
        ArrayList<Cell> newMoves = new ArrayList<>();
        for (Cell cMove : list) {
            loadBackup();
            Controller testController = new Controller(cellHolderCopy, whiteTurn);
            if (testController.tryMove(cMove.getRow(), cMove.getCol())) {
                newMoves.add(cMove);
            }
        }
        byteData = null;
        cellHolderCopy = null;
        return newMoves;
    }

    private boolean isCheck() {
        return whiteKing.checkForCheck(whiteKing.getCurrentCell().getRow(), whiteKing.getCurrentCell().getCol()) || blackKing.checkForCheck(blackKing.getCurrentCell().getRow(), blackKing.getCurrentCell().getCol());
    }

    private boolean isCheckMate() {
        pieceBase tempCurrentPiece = currentPiece;
        for (pieceBase piece : pieceList) {
            currentPiece = piece;
            if (currentPiece.getIsWhite() == whiteTurn) {
                loadArrays();
                if (!currentPiece.getAllowedMoves().isEmpty() || !currentPiece.getAllowedCaptures().isEmpty()) {
                    currentPiece = tempCurrentPiece;
                    return false;
                }
                if (currentPiece instanceof pieceFirstMoveDependency && !((pieceFirstMoveDependency) currentPiece).getSpecialMoves().isEmpty()) {
                    currentPiece = tempCurrentPiece;
                    return false;
                }
            }
        }
        currentPiece = tempCurrentPiece;
        return true;
    }
}
