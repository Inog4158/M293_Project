package Buttons;

import javax.swing.*;

public class chessboardButton extends JButton {
    private final int row;
    private final int col;

    public chessboardButton(int r, int c) {
        super();
        row = r;
        col = c;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
}
