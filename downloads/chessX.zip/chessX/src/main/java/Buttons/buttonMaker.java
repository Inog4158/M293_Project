package Buttons;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

import static Client.DesignChooser.darkColor;
import static Client.DesignChooser.lightColor;


public class buttonMaker {

    public static chessboardButton getjButton(Insets buttonMargin, int row, int col) {
        chessboardButton b = new chessboardButton(row, col);
        b.setMargin(buttonMargin);
        ImageIcon icon = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
        b.setIcon(icon);
        if ((col % 2 == 1 && row % 2 == 1) || (col % 2 == 0 && row % 2 == 0)) {
            b.setBackground(lightColor);
        } else {
            b.setBackground(darkColor);
        }
        return b;
    }
}
