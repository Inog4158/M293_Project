package Buttons;

import Cells.Cell;
import Pieces.pieceBase;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

import static Client.DesignChooser.*;

public class buttonEditor {
    private final JButton[][] chessBoardSquares;


    public buttonEditor(JButton[][] CBS) {
        chessBoardSquares = CBS;
    }

    public void placePieceIcon(pieceBase piece) {
        Cell c = piece.getCurrentCell();
        chessBoardSquares[c.getRow()][c.getCol()].setIcon(piece.getImg());
    }

    public void clearButtonIcons(int row, int col) {
        ImageIcon icon = new ImageIcon(new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB));
        chessBoardSquares[col][row].setIcon(icon);
    }

    public void clearBoardIcons() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                this.clearButtonIcons(r, c);
            }
        }
    }

    public void resetSquareColors() {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if ((col % 2 == 1 && row % 2 == 1) || (col % 2 == 0 && row % 2 == 0)) {
                    chessBoardSquares[row][col].setBackground(lightColor);
                } else {
                    chessBoardSquares[row][col].setBackground(darkColor);
                }
            }
        }
    }

    public JButton[][] getChessBoardSquares() {
        return chessBoardSquares;
    }

    public void setBackground(int row, int col, Color color) {
        chessBoardSquares[row][col].setBackground(color);
    }
}
