package Pieces;

import Cells.CellBoard;

public class pieceKnight extends pieceBase {
    public pieceKnight(CellBoard CB, String rootPath, boolean isW) {
        super(CB, rootPath);
        name = "knight";
        value = 3;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
    }

    private void addAllAllowedMoves(int r, int c){
        for (int dr = -2; dr <= 2; dr++) {
            for (int dc = -2; dc <= 2; dc++) {
                if (Math.abs(dr) + Math.abs(dc) == 3) {
                    addAllowedMoves(r + dr, c + dc);
                }
            }
        }
    }

    @Override
    public void canMove() {
        clearMoves();
        addAllAllowedMoves(currentCell.getRow(), currentCell.getCol());
    }
}
