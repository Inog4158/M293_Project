package Pieces;

import Cells.Cell;
import Cells.CellBoard;
import Client.DesignChooser;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class piecePawn extends pieceFirstMoveDependency {
    private ArrayList<pieceBase> pieceList;

    public piecePawn(CellBoard CB, String rootPath,  boolean isW, ArrayList<pieceBase> pl) {
        super(CB, rootPath);
        name = "pawn";
        value = 1;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
        pieceList = pl;
    }

    public void addAllowedMoves(int r, int c) {
        movebool = false;
        if (r > -1 && r < 8 && c > -1 && c < 8) {
            Cell goal = cellHolder.getCell(r, c);
            if (goal.hasPiece()) {
                movebool = true;
                return;
            }
            addAllowedMoves(goal);
        }
    }

    public void setCurrentCell(int r, int c) {
        if (currentCell != null) {
            getCurrentCell().setCurrentPiece(null);
            if (getHasNotMoved()) {
                setHasNotMoved(false);
            }
        }
        currentCell = cellHolder.getCell(r, c);
        currentCell.setCurrentPiece(this);
    }

    public void addCanCapture(int r, int c) {
        movebool = false;
        if (r > -1 && r < 8 && c > -1 && c < 8) {
            Cell goal = cellHolder.getCell(r, c);
            if (goal.hasPiece()) {
                if (!goal.getPieceColor() == this.isWhite) {
                    addAllowedCaptures(goal);
                }
                movebool = true;
            }
        }
    }

    @Override
    public void canMove() {
        clearMoves();
        int r = currentCell.getRow();
        int c = currentCell.getCol();
        if (getIsWhite() && r == 1) {
            addSpecialMoves(0, c);
        } else if (!getIsWhite() && r == 6) {
            addSpecialMoves(7, c);
        }
        if (getHasNotMoved()) {
            if (isWhite) {
                if (!cellHolder.getCell(r - 1, c).hasPiece()) {
                    addSpecialMoves(r - 2, c);
                }
            } else {
                if (!cellHolder.getCell(r + 1, c).hasPiece()) {
                    addSpecialMoves(r + 2, c);
                }
            }
        }
        if (isWhite) {
            if (r > 1) {
                addAllowedMoves(r - 1, c);
            }
            addCanCapture(r - 1, c - 1);
            addCanCapture(r - 1, c + 1);
        } else {
            if (r < 6) {
                addAllowedMoves(r + 1, c);
            }
            addCanCapture(r + 1, c - 1);
            addCanCapture(r + 1, c + 1);
        }
    }

    public void checkEvolution() {
        if (getCurrentCell().getRow() == 0 || getCurrentCell().getRow() == 7) {

            ImageIcon[] imageIcons = {evoIcon("queen"), evoIcon("rook"), evoIcon("bishop"), evoIcon("knight")};

            JOptionPane pane = new JOptionPane("Choose your Piece");
            pane.setOptions(imageIcons);
            pane.setBackground(DesignChooser.lightColor);
            JDialog dialog = pane.createDialog(pane, "Pawn promotion");
            dialog.show();

            if(pane.getValue() == null){
                spawnNewPiece(getNewPiece(0));
            } else {
                for (int i = 0; i < imageIcons.length; i++) {
                    if (pane.getValue().equals(imageIcons[i])) {
                        spawnNewPiece(getNewPiece(i));
                        break;
                    }
                }
            }
            this.currentCell = null;
            pieceList.remove(this);

        }
    }
    private pieceBase getNewPiece(int i){
        switch (i) {
            default:
            case 0:
                return new pieceQueen(cellHolder, rootPath, getIsWhite());
            case 1:
                return new pieceRook(cellHolder, rootPath, getIsWhite());
            case 2:
                return new pieceBishop(cellHolder, rootPath, getIsWhite());
            case 3:
                return new pieceKnight(cellHolder, rootPath, getIsWhite());
        }
    }
    private void spawnNewPiece(pieceBase p){
        pieceList.add(p);
        pieceList.get(pieceList.indexOf(p)).setCurrentCell(getCurrentCell().getRow(), getCurrentCell().getCol());
    }

    ImageIcon evoIcon(String n) {
        String c = "black";
        if (isWhite) {
            c = "white";
        }
        ImageIcon icon_raw = new ImageIcon(rootPath+"images/" + DesignChooser.style + "/" + c + "-" + n + ".png");
        Image img_raw = icon_raw.getImage();
        Image img_Sized = img_raw.getScaledInstance(64, 64, Image.SCALE_SMOOTH);
        return new ImageIcon(img_Sized);
    }

    public void setEnPassant(pieceBase currentPiece, piecePawn pawn2Felder) {
        if (pawn2Felder == null) {
            return; // returns if there is no possible enemy pawn for en passant
        }

        int row = currentPiece.getCurrentCell().getRow();
        int col = currentPiece.getCurrentCell().getCol();
        if(row != 3 && row != 4){
            return; // returns if the current pawn is not on a row for a possible en passant
        }

        int m = 1;
        if(!pawn2Felder.getIsWhite()){
            m = -1; // sets the direction for the attack
        }

        int goalCol = pawn2Felder.getCurrentCell().getCol();
        if (goalCol == col - 1 || goalCol == col + 1) {
            addSpecialMoves(row + m, goalCol);
        }
    }
}
