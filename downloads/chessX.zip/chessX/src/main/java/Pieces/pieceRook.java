package Pieces;

import Cells.CellBoard;

public class pieceRook extends pieceFirstMoveDependency {
    public pieceRook(CellBoard CB, String rootPath, boolean isW) {
        super(CB, rootPath);
        name = "rook";
        value = 5;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
    }

    public void canMove() {
        clearMoves();
        checkDirection(1, 0);
        checkDirection(-1, 0);
        checkDirection(0, 1);
        checkDirection(0, -1);
    }

    public boolean GetHasMove() {
        return getHasNotMoved();
    }
}
