package Pieces;

import Cells.Cell;
import Cells.CellBoard;

import java.util.ArrayList;
import java.util.List;

public class pieceKing extends pieceFirstMoveDependency {
    private boolean isUnderCheck;
    private final ArrayList<Cell> enemyThatCheckedMe = new ArrayList<>();

    public pieceKing(CellBoard CB, String rootPath, boolean isW) {
        super(CB, rootPath);
        name = "king";
        value = 99;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
        isUnderCheck = false;
    }

    private void addCheckDirectionForChecks(int r, int c) {
        movebool = false;
        if (r > -1 && r < 8 && c > -1 && c < 8) {
            Cell goal = cellHolder.getCell(r, c);
            if (goal.hasPiece()) {
                if (!goal.getPieceColor() == isWhite) {
                    enemyThatCheckedMe.add(goal);
                }
                movebool = true;
            }
        }
    }

    private void checkDirectionForChecks(int dirRow, int dirCol, int r, int c) {
        for (int i = 1; i < 8; i++) {
            addCheckDirectionForChecks(r + (i * dirRow), c + (i * dirCol));
            if (movebool) {
                break;
            }
        }
    }
    private void checkAllDirectionForChecks(int r, int c){
        for(int dr = -1; dr <= 1; dr++){
            for(int dc = -1; dc <= 1; dc++){
                if(dr == 0 && dc == 0){
                    continue;
                }
                checkDirectionForChecks(dr, dc, r, c);
            }
        }
    }
    private void addKightCheckDirectionForChecks(int r, int c){
        for (int dr = -2; dr <= 2; dr++) {
            for (int dc = -2; dc <= 2; dc++) {
                if (Math.abs(dr) + Math.abs(dc) == 3) {
                    addAllowedMoves(r + dr, c + dc);
                }
            }
        }
    }

    public boolean checkForCheck(int r, int c) {
        isUnderCheck = false;
        enemyThatCheckedMe.clear();
        checkAllDirectionForChecks(r, c); // adds all possible cells in all directions where a piece could check the king
        addKightCheckDirectionForChecks(r, c); // adds the possible 8 cells from where a knight could check the King

        if (!enemyThatCheckedMe.isEmpty()) {
            for (Cell cell : enemyThatCheckedMe) {
                cell.getPiece().canMove();
                List<Cell> combinedList = new ArrayList<>();
                combinedList.addAll(cell.getPiece().getAllowedCaptures());
                combinedList.addAll(cell.getPiece().getAllowedMoves());
                for (Cell cap : combinedList) {
                    if (cellHolder.getCell(r, c) == cap) {
                        isUnderCheck = true;
                        break;
                    }
                }
            }
        }
        return isUnderCheck;
    }


    private void addAllAllowedMoves(int r, int c){
        for(int dr = -1; dr <= 1; dr++){
            for(int dc = -1; dc <= 1; dc++){
                if(dr == 0 && dc == 0){
                    continue;
                }
                addAllowedMoves(r+dr, c+dc);
            }
        }
    }
    @Override
    public void canMove() {
        clearMoves();
        addAllAllowedMoves(currentCell.getRow(),  currentCell.getCol());
    }


    public void rochade() {
        getSpecialMoves().clear();
        if (!getHasNotMoved()) {
            return; // returns if king has already moved before
        }
        if(checkForCheck(currentCell.getRow(), currentCell.getCol())){
            return; // returns if king is under check
        }
        int r = 0;
        if (isWhite) {
            r = 7;
        }
        rochadeGetRook(r, 7, 5, 6, null);
        rochadeGetRook(r, 0, 3, 2, 1);
    }
    private void rochadeGetRook(int r, int rookPos, int rookGoal, int kingGoal, Integer rookPassBy){
        if (!(cellHolder.getCell(r, rookPos).hasPiece() && cellHolder.getCell(r, rookPos).getPiece().getName().equals("rook"))) {
            return; // returns if no rook is at given position
        }
        pieceRook rook1 = cellHolder.getCell(r, rookPos).getRook();
        if (!rook1.getHasNotMoved()) {
            clearMoves();
            rook1.clearMoves();
            return; // returns if rook at given positon has already moved before
        }
        if (cellHolder.getCell(r, kingGoal).hasPiece() || cellHolder.getCell(r, rookGoal).hasPiece()) {
            return; //returns if destination cells are blocked
        }
        if(rookPassBy == null || !cellHolder.getCell(r, rookPassBy).hasPiece()) {
            return; // if the selected rook has a pass by field and that field is not empty
        }
        if (!checkForCheck(r, kingGoal) && !checkForCheck(r, rookGoal)) {
            addSpecialMoves(r, kingGoal); // adds special move for king
            rook1.addSpecialMoves(r, rookGoal); // adds special move for rook
        }
    }
}
