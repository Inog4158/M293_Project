package Pieces;

import Cells.Cell;
import Cells.CellBoard;

import java.util.ArrayList;

public abstract class pieceFirstMoveDependency extends pieceBase {
    private Boolean hasNotMoved;
    private ArrayList<Cell> specialMoves = new ArrayList<>();

    public pieceFirstMoveDependency(CellBoard CB, String rootPath) {
        super(CB, rootPath);
        hasNotMoved = true;
    }

    public ArrayList<Cell> getSpecialMoves() {
        return specialMoves;
    }

    public void addSpecialMoves(int r, int c) {
        movebool = false;
        if (r > -1 && r < 8 && c > -1 && c < 8) {
            Cell goal = cellHolder.getCell(r, c);
            if (goal.hasPiece()) {
                movebool = true;
                return;
            }
            if (!specialMoves.contains(goal)) {
                specialMoves.add(goal);
            }
        }
    }

    public void setHasNotMoved(Boolean hasNotMoved) {
        this.hasNotMoved = hasNotMoved;
    }

    public void setCurrentCell(int r, int c) {
        if (currentCell != null) {
            getCurrentCell().setCurrentPiece(null);
            if (hasNotMoved) {
                hasNotMoved = false;
            }
        }
        currentCell = cellHolder.getCell(r, c);
        currentCell.setCurrentPiece(this);
    }

    public void clearMoves() {
        super.clearMoves();
        specialMoves.clear();
    }

    public Boolean getHasNotMoved() {
        return hasNotMoved;
    }


    public void setSpecialMoves(ArrayList<Cell> specialMoves) {
        this.specialMoves = specialMoves;
    }
}
