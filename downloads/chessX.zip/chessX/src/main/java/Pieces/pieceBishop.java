package Pieces;

import Cells.CellBoard;

public class pieceBishop extends pieceBase {
    public pieceBishop(CellBoard CB, String rootPath, boolean isW) {
        super(CB, rootPath);
        name = "bishop";
        value = 3;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
    }

    @Override
    public void canMove() {
        clearMoves();
        checkDirection(1, 1);
        checkDirection(-1, 1);
        checkDirection(1, -1);
        checkDirection(-1, -1);
    }
}
