package Pieces;

import Cells.Cell;
import Cells.CellBoard;
import Client.DesignChooser;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public abstract class pieceBase implements Serializable {
    protected String rootPath;

    protected int value;
    protected String name;
    protected ImageIcon img;
    protected Cell currentCell;
    private ArrayList<Cell> allowedMoves = new ArrayList<>();
    private ArrayList<Cell> allowedCaptures = new ArrayList<>();
    protected boolean isWhite;
    protected CellBoard cellHolder;
    protected boolean movebool;

    public pieceBase(CellBoard CB, String rootPath) {
        cellHolder = CB;
        this.rootPath = rootPath;
    }

    public Cell getCurrentCell() {
        return currentCell;
    }

    public void setCurrentCell(int r, int c) {
        if (currentCell != null) {
            getCurrentCell().setCurrentPiece(null);
        }
        currentCell = cellHolder.getCell(r, c);
        currentCell.setCurrentPiece(this);
    }

    public ImageIcon getImg() {
        return findIcon();
    }

    ImageIcon findIcon() {
        String c = "black";
        if (isWhite) {
            c = "white";
        }
        ImageIcon icon_raw = new ImageIcon(rootPath+"images/" + DesignChooser.style + "/" + c + "-" + name + ".png");
        Image img_raw = icon_raw.getImage();
        Image img_Sized = img_raw.getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(img_Sized);
    }

    public abstract void canMove();

    public String getName() {
        return name;
    }

    public boolean getIsWhite() {
        return isWhite;
    }

    public void addAllowedMoves(int r, int c) {
        movebool = false;
        if (r > -1 && r < 8 && c > -1 && c < 8) {
            Cell goal = cellHolder.getCell(r, c);
            if (goal.hasPiece()) {
                if (!goal.getPieceColor() == isWhite) {
                    allowedCaptures.add(goal);
                }
                movebool = true;
                return;
            }
            allowedMoves.add(goal);
        }
    }

    void checkDirection(int dirRow, int dirCol) {
        for (int i = 1; i < 8; i++) {
            addAllowedMoves(currentCell.getRow() + (i * dirRow), currentCell.getCol() + (i * dirCol));
            if (movebool) {
                break;
            }
        }
    }

    public void clearMoves() {
        allowedMoves.clear();
        allowedCaptures.clear();
    }

    public int getValue() {
        return value;
    }

    public void addAllowedMoves(Cell x) {
        allowedMoves.add(x);
    }

    public void addAllowedCaptures(Cell x) {
        allowedCaptures.add(x);
    }

    public ArrayList<Cell> getAllowedMoves() {
        return allowedMoves;
    }

    public ArrayList<Cell> getAllowedCaptures() {
        return allowedCaptures;
    }

    public void setAllowedMoves(ArrayList<Cell> allowedMoves) {
        this.allowedMoves = allowedMoves;
    }

    public void setAllowedCaptures(ArrayList<Cell> allowedCaptures) {
        this.allowedCaptures = allowedCaptures;
    }
}

