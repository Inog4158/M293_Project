package Pieces;

import Cells.CellBoard;

public class pieceQueen extends pieceBase {
    public pieceQueen(CellBoard CB, String rootPath, boolean isW) {
        super(CB, rootPath);
        name = "queen";
        value = 9;
        currentCell = null;
        isWhite = isW;
        img = findIcon();
    }

    @Override
    public void canMove() {
        clearMoves();
        checkDirection(1, 0);
        checkDirection(-1, 0);
        checkDirection(0, 1);
        checkDirection(0, -1);
        checkDirection(1, 1);
        checkDirection(-1, 1);
        checkDirection(1, -1);
        checkDirection(-1, -1);
    }
}
