package Cells;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class CellBoard implements Serializable {
    private final ArrayList<Cell> cells;

    public CellBoard() {
        cells = new ArrayList<>();
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Cell cell = new Cell(row, col, row + String.valueOf(col));
                cells.add(cell);
            }
        }
    }

    public Cell getCell(int row, int col) {
        for (Cell c : cells) {
            if (Objects.equals(c.getName(), row + String.valueOf(col))) {
                return c;
            }
        }
        return null;
    }

    public void clearSelections() {
        for (Cell c : cells) {
            c.setIsSelected(false);
        }
    }

    public void clearMoveTest() {
        for (Cell c : cells) {
            c.setMoveTest(false);
        }
    }

    public Cell getMoveTest() {
        for (Cell c : cells) {
            if (c.getMoveTest()) {
                return c;
            }
        }
        return null;
    }

    public Cell getSelected() {
        for (Cell c : cells) {
            if (c.getIsSelected()) {
                return c;
            }
        }
        return null;
    }

    public boolean hasSelected() {
        for (Cell c : cells) {
            if (c.getIsSelected()) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Cell> getCells() {
        return cells;
    }
}
