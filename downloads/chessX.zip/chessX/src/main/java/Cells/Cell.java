package Cells;

import Pieces.pieceBase;
import Pieces.piecePawn;
import Pieces.pieceRook;

import java.io.Serializable;
import java.util.ArrayList;

public class Cell implements Serializable {
    private final int row;
    private final int col;
    private final String name;
    private pieceBase currentPiece;
    private boolean isSelected;
    private boolean MoveTest;

    Cell(int r, int c, String n) {
        row = r;
        col = c;
        name = n;
        currentPiece = null;
        isSelected = false;
    }

    public pieceBase getPiece() {
        return currentPiece;
    }

    public void setCurrentPiece(pieceBase p) {
        currentPiece = p;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public String getName() {
        return name;
    }

    public boolean hasPiece() {
        return currentPiece != null;
    }

    public boolean getPieceColor() {
        return currentPiece.getIsWhite();
    }

    public pieceBase getPiece(ArrayList<pieceBase> pieceList) {
        for (pieceBase p : pieceList) {
            if (p.getCurrentCell() == this) {
                return p;
            }
        }
        return null;
    }

    public pieceRook getRook() {
        return (pieceRook) currentPiece;
    }

    public piecePawn getPawn() {
        return (piecePawn) currentPiece;
    }

    public void setIsSelected(boolean mode) {
        isSelected = mode;
    }

    public boolean getIsSelected() {
        return isSelected;
    }

    public void setMoveTest(boolean b) {
        MoveTest = b;
    }

    public boolean getMoveTest() {
        return MoveTest;
    }
}
