package Files;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Csv {
    public static ArrayList<String[]> read(Path path) {
        try {
            CSVReader reader = new CSVReader(new FileReader(path.toString()));
            List<String[]> data = reader.readAll();
            return new ArrayList<>(data);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static void write(Path path, ArrayList<String[]> data) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(path.toString()))) {
            for (String[] row : data) {
                writer.writeNext(row);
            }
            System.out.println("Written successfully");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}