package Client;

import Files.Csv;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;

public class DesignChooser implements ActionListener {
    private Path path;
    private static final Color LIGHT_BROWN = new Color(255, 233, 197);
    private static final Color DARK_BROWN = new Color(135, 91, 16);
    public static Color lightColor = LIGHT_BROWN;
    public static Color darkColor = DARK_BROWN;
    private Client.VisualController visualController;
    public static String style = "style1";
    private String[] styles;
    private String rootPath;

    public DesignChooser(VisualController vc, String rootPath) {
        this.rootPath = rootPath;
        path = Path.of(rootPath+"data/design.csv");
        visualController = vc;
        int counter = new File(rootPath+"images\\").list().length;
        String[] temp = new String[counter];
        for (int i = 0; i < counter; i++){
            temp[i] = "style"+(i+1);
        }
        styles = temp;
    }

    public void loadProfile() {
        if (!loadDesign()) {
            actionPerformed(null);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ImageIcon[] imageIcons = getIcons();

        JOptionPane pane = new JOptionPane("Choose your Style");
        pane.setOptions(imageIcons);
        JDialog dialog = pane.createDialog(pane, "Designe Chooser");
        dialog.show();

        if (pane.getValue() != null) {
            style = "style1";
            for (int i = 0; i < styles.length; i++) {
                if (pane.getValue().equals(imageIcons[i])) {
                    style = styles[i];
                }
            }
        }

        lightColor = JColorChooser.showDialog(null, "Choose a light Color", LIGHT_BROWN);
        if (lightColor == null) {
            lightColor = LIGHT_BROWN;
        }
        darkColor = JColorChooser.showDialog(null, "Choose a dark Color", DARK_BROWN);
        if (darkColor == null) {
            darkColor = DARK_BROWN;
        }
        saveDesign();
        visualController.display();
    }

    private ImageIcon[] getIcons() {
        ImageIcon[] icons = new ImageIcon[styles.length];
        int i = 0;
        for (String sty : styles) {
            ImageIcon icon_raw = new ImageIcon(rootPath+"images/" + sty + "/black-pawn.png");
            Image img_raw = icon_raw.getImage();
            Image img_Sized = img_raw.getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            icons[i] = new ImageIcon(img_Sized);
            i++;
        }

        return icons;
    }

    private void saveDesign() {
        ArrayList<String[]> data = new ArrayList<>();
        data.add(new String[]{"lightcolor", String.valueOf(lightColor.getRed()), String.valueOf(lightColor.getGreen()), String.valueOf(lightColor.getBlue())});
        data.add(new String[]{"darkcolor", String.valueOf(darkColor.getRed()), String.valueOf(darkColor.getGreen()), String.valueOf(darkColor.getBlue())});
        data.add(new String[]{"piecestyle", style});
        Csv.write(path, data);
    }

    private boolean loadDesign() {
        ArrayList<String[]> data = Csv.read(path);
        if (data.size() > 3) {
            System.out.println("zu klein" + data.size());
            return false;
        }
        lightColor = changeColor(getRGB(data.get(0)));
        darkColor = changeColor(getRGB(data.get(1)));
        style = data.get(2)[1];
        return true;
    }

    private int[] getRGB(String[] stringRGB) {
        int[] intRGB = new int[3];
        for (int i = 0; i < 3; i++) {
            intRGB[i] = Integer.parseInt(stringRGB[i + 1]);
        }
        return intRGB;
    }

    private Color changeColor(int[] RGB) {
        return new Color(RGB[0], RGB[1], RGB[2]);
    }
}
