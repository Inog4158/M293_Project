package Client;

import Buttons.buttonEditor;
import Buttons.chessboardButton;
import Cells.Cell;
import Controller.Controller;
import Pieces.pieceBase;
import Pieces.pieceFirstMoveDependency;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;

public class VisualController implements ActionListener {
    private boolean imWhite = true;
    private Controller controller;
    private final buttonEditor buttonEdit;
    private final JLabel turnLabel;
    private final clientConnector client;
    private JPanel gui;

    public VisualController(buttonEditor be, JLabel tl, clientConnector cl, JPanel GUI) {
        gui = GUI;
        client = cl;
        buttonEdit = be;
        turnLabel = tl;
        controller = null;
    }

    public void display() {
        changeGuiBoard();
        if (controller == null) {
            buttonEdit.resetSquareColors();
            return;
        }
        if (controller.isWhiteTurn()) {
            turnLabel.setText("White's Turn");
        } else {
            turnLabel.setText("Black's Turn");
        }
        buttonEdit.resetSquareColors();
        if (controller.getCellHolder().hasSelected()) {
            highlightAllowedMoves();
        }
        buttonEdit.clearBoardIcons();
        for (pieceBase P : controller.getPieceList()) {
            buttonEdit.placePieceIcon(P);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        chessboardButton b = (chessboardButton) e.getSource();
        if (!client.isConnected()) {
            return;
        }
        client.write(b.getRow(), b.getCol());
    }

    private void highlightAllowedMoves() {
        pieceBase piece = controller.getCellHolder().getSelected().getPiece();
        for (Cell c : piece.getAllowedMoves()) {
            buttonEdit.setBackground(c.getRow(), c.getCol(), Color.RED);
        }
        for (Cell c : piece.getAllowedCaptures()) {
            buttonEdit.setBackground(c.getRow(), c.getCol(), Color.BLUE);
        }
        if (piece instanceof pieceFirstMoveDependency) {
            for (Cell c : ((pieceFirstMoveDependency) piece).getSpecialMoves()) {
                buttonEdit.setBackground(c.getRow(), c.getCol(), Color.MAGENTA);
            }
        }
    }

    public void changeGuiBoard() {
        JButton[][] chessBoardSquares = buttonEdit.getChessBoardSquares();
        JPanel chessboard = (JPanel) gui.getComponent(1);
        chessboard.removeAll();
        chessboard.add(new JLabel(""));
        for (int row = 0; row < 8; row++) {
            chessboard.add(new JLabel("ABCDEFGH".substring(row, row + 1), SwingConstants.CENTER));
        }
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if (col == 0) {
                    if (!imWhite) {
                        chessboard.add(new JLabel("" + (row + 1), SwingConstants.CENTER));
                    } else {
                        chessboard.add(new JLabel("" + (7 - row + 1), SwingConstants.CENTER));
                    }
                }
                if (imWhite) {
                    chessboard.add(chessBoardSquares[row][col]);
                } else {
                    chessboard.add(chessBoardSquares[7 - row][7 - col]);
                }

            }
        }
    }

    public void setImWhite(boolean imWhite) {
        this.imWhite = imWhite;
        changeGuiBoard();
    }

    public boolean imWhite() {
        return imWhite;
    }

    public void setController(Controller co) {
        this.controller = co;
    }

    public void showEndAnimation(String TEXT, String GIF, ThreadGroup threadGroup) {
        Window[] windows = Window.getWindows();
        for (Window window : windows) {
            if (window instanceof JFrame) {
                JFrame frame = (JFrame) window;
                frame.dispose();
            }
        }
        JDialog dialog = new JDialog(new JFrame(), false);
        JPanel gifPanel = new JPanel();
        URL url = this.getClass().getResource("/gif/"+GIF+".gif");
        Icon icong = new ImageIcon(url);
        JLabel label = new JLabel(icong);
        JLabel text = new JLabel(TEXT);
        gifPanel.add(label);
        text.setFont(new Font("Arial", Font.PLAIN, 24));
        JPanel textPanel = new JPanel();
        textPanel.add(BorderLayout.CENTER, text);
        dialog.add(BorderLayout.CENTER, gifPanel);
        dialog.add(BorderLayout.NORTH, textPanel);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                threadGroup.interrupt();
                System.exit(0);
            }
        });
        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.setVisible(true);
    }
}
