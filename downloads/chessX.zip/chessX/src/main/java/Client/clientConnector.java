package Client;

import Controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class clientConnector implements ActionListener {
    private boolean isConnected;
    private ThreadGroup threadGroup;
    private VisualController visualController;
    private Controller controller;
    String ipAdress = "127.0.0.1";
    ObjectInputStream reader;
    ObjectOutputStream writer;
    Socket sock;

    public clientConnector(ThreadGroup threadGroup){
        this.threadGroup  = threadGroup;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void los(VisualController vc) {
        visualController = vc;
        isConnected = false;
    }

    private void netzwerkEinrichten() {
        try {
            sock = new Socket(ipAdress, 5000);
            writer = new ObjectOutputStream(sock.getOutputStream());
            writer.flush();
            reader = new ObjectInputStream(sock.getInputStream());

            System.out.println("Netzwerkverbindung steht");
            isConnected = true;
            Thread readerThread = new Thread(threadGroup,new read());
            readerThread.start();
            write(-1, -1);

        } catch (IOException ex) {
            System.out.println("Server not found");
        }
    }

    public void actionPerformed(ActionEvent ev) {
        if(!isConnected) {
            readIpAddress();
            chooseColor();
            netzwerkEinrichten();
        }
    }
    public void connectNOW(){
        ipAdress = "127.0.0.1";
        chooseColor();
        netzwerkEinrichten();
    }

    private void readIpAddress(){
        String result = JOptionPane.showInputDialog(new JFrame(), "Enter IP-Address:", "Connector", JOptionPane.QUESTION_MESSAGE);
        if(result.equals("localhost")){
            result = "127.0.0.1";
        }
        boolean isValid = validIP(result);
        while (!isValid) {
            result = JOptionPane.showInputDialog(new JFrame(), "Invalid IP-Address\nFormat: 1.1.1.1 - 255.255.255.255\nEnter IP-Address:", "Connector", JOptionPane.ERROR_MESSAGE);
            if(result.equals("localhost")){
                result = "127.0.0.1";
            }
            isValid = validIP(result);
        }
        ipAdress = result;
        System.out.println(ipAdress);
    }
    private void chooseColor(){
        JPanel panel = new JPanel(new GridLayout(0, 1));
        JComboBox<String> color = new JComboBox<>(new String[]{"White", "Black"});
        panel.add(color);
        int check;
        do {
            check = JOptionPane.showOptionDialog(null, panel, "Choose Color", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, null);
        } while (check != JOptionPane.OK_OPTION);
        System.out.println(color.getSelectedItem());
        visualController.setImWhite(color.getSelectedItem().equals("White"));
    }
    private boolean validIP(String ip){
        if(ip == null){
            return true;
        }
        try {
            String[] array = ip.split("\\.");
            for(String a : array){
                int x = Integer.parseInt(a);
                if (0 > x || x > 255){
                    return false;
                }
            }
            return array.length == 4;
        } catch (Exception e){
            return false;
        }

    }


    public void write(int row, int col) {
        try {
            writer.writeObject(row + ":" + col);
            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private class read implements Runnable {
        public void run() {
            Object receivedObject;
            try {
                while ((receivedObject = reader.readObject()) != null) {
                    if(receivedObject instanceof Boolean){
                        String color = "Weiss";
                        String endResult;
                        if((Boolean) receivedObject) {
                            color = "Schwarz";
                        }
                        if((Boolean) receivedObject == visualController.imWhite()){
                            endResult = "lost";
                        } else {
                            endResult = "won";
                        }

                        visualController.showEndAnimation("Schachmatt! "+color+" hat gewonnen", endResult, threadGroup);
                    }
                    else {
                        ByteArrayInputStream bais = new ByteArrayInputStream((byte[]) receivedObject);
                        try {
                            controller = (Controller) new ObjectInputStream(bais).readObject();
                            bais.close();

                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                        visualController.setController(controller);
                        visualController.display();
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}