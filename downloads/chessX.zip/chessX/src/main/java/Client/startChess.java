package Client;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class startChess {
    private String rootPath = "C:\\Program Files\\chessX\\";
    public static void main(String[] args){
        startChess setup = new startChess();
        setup.begin(args[0]);
    }

    public void begin(String rootPath){
        ThreadGroup threadGroup = new ThreadGroup("alleThreads");

        this.rootPath = rootPath;
        chessSetup cb = new chessSetup(rootPath, threadGroup);

        JFrame f = new JFrame("Chess X Client");
        f.add(cb.getGui());
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                Exit(threadGroup, f);
            }
        });
        f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        f.setLocationByPlatform(true);
        ImageIcon icon = new ImageIcon(rootPath+"images/style1/white-pawn.png");
        f.setIconImage(icon.getImage());

        f.pack();
        f.setMinimumSize(f.getSize());
        f.setVisible(true);
    }
    private void Exit(ThreadGroup threadGroup, JFrame f){
        f.dispose();
        threadGroup.interrupt();
        System.exit(0);
    }
}

