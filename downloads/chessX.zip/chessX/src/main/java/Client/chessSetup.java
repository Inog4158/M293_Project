package Client;

import Buttons.buttonEditor;
import Buttons.buttonMaker;
import Buttons.chessboardButton;

import Server.ScoreBoard;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.*;
import javax.swing.border.*;

public class chessSetup {
    private boolean imWhite = true;
    private JPanel chessboardWhite;
    private final JPanel gui;
    private JToolBar tools = new JToolBar();
    private JButton chooseDesign = new JButton("Design");
    private clientConnector client;

    chessSetup(String rootPath, ThreadGroup threadGroup) {
        gui = new JPanel(new BorderLayout(3, 3));
        JLabel turnLabel = new JLabel("");
        turnLabel.setForeground(Color.BLUE);

        tools.setFloatable(false);
        gui.add(tools, BorderLayout.PAGE_START);

        JButton newServer = new JButton("New Server");
        JButton conntectButton = new JButton("Connect");
        JButton restoreButton = new JButton("Restore");
        tools.add(newServer);
        tools.add(conntectButton);
        tools.add(restoreButton); // TODO - add functionality!
        tools.addSeparator();
        tools.add(chooseDesign);
        tools.addSeparator();
        tools.add(turnLabel);


       newServer.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {

               /*JComboBox<String> serverType = new JComboBox<>(new String[]{"Online", "Offline"});
               JPanel panel = new JPanel(new GridLayout(0, 1));

               JPanel textPanel = new JPanel();
               JTextField field2 = new JTextField();
               textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.X_AXIS));
               textPanel.add(new JLabel("Name    "));
               textPanel.add(field2);
               field2.requestFocus();
               field2.selectAll();

               panel.add(textPanel);
               panel.add(serverType);
               int result = JOptionPane.showConfirmDialog(null, panel, "Create Server", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
               if (!(result == JOptionPane.OK_OPTION)) {
                   JOptionPane.showMessageDialog(new JFrame(), "Canceled");
                   return;
               }*/
               // später wieder entfernen und oberen teil einblenden

               new Server.chessSetup(rootPath, threadGroup);
               try (final DatagramSocket datagramSocket = new DatagramSocket()) {
                   datagramSocket.connect(InetAddress.getByName("8.8.8.8"), 12345);
                   String ip = datagramSocket.getLocalAddress().getHostAddress();
                   client.connectNOW();
                   JOptionPane.showMessageDialog(new JFrame(), "New  Server started\nIP-Address: "+ip); // SERVER TYPE wieder einbauen


               } catch (Exception ex){
                   System.out.println("Error while trying to get your IP-Address");
               }
           }
       });

        createChessBoard();
        chessboardButton[][] chessBoardSquares = new chessboardButton[8][8];
        buttonEditor buttonEdit = new buttonEditor(chessBoardSquares);

        client = new clientConnector(threadGroup);
        conntectButton.addActionListener(client);

        VisualController visualController = new VisualController(buttonEdit, turnLabel, client, gui);
        client.los(visualController);
        restoreButton.addActionListener(visualController);

        chooseDesign.addActionListener(new DesignChooser(visualController, rootPath));
        new DesignChooser(visualController, rootPath).loadProfile();

        createButtons(chessBoardSquares, visualController);

        visualController.changeGuiBoard();
        visualController.display();
    }

    public final JComponent getGui() {
        return gui;
    }


    private void createButtons(chessboardButton[][] chessBoardSquares, VisualController visualController) {
        Insets buttonMargin = new Insets(0, 0, 0, 0);
        for (int row = 0; row < chessBoardSquares.length; row++) {
            for (int col = 0; col < chessBoardSquares[row].length; col++) {
                chessboardButton b = buttonMaker.getjButton(buttonMargin, row, col);
                b.addActionListener(visualController);
                chessBoardSquares[row][col] = b;
            }
        }
    }

    private void createChessBoard() {
        gui.setBorder(new EmptyBorder(5, 5, 5, 5));
        chessboardWhite = new JPanel(new GridLayout(0, 9));
        chessboardWhite.setBorder(new LineBorder(Color.BLACK));
        gui.add(chessboardWhite);
    }

    private ScoreBoard createScoreBoard() {
        JLabel Score = new JLabel();
        JLabel Winning = new JLabel();
        tools.addSeparator();
        tools.addSeparator();
        tools.add(Winning);
        ScoreBoard scoreBoard = new ScoreBoard(Score, Winning);
        scoreBoard.updateScore();
        return scoreBoard;
    }
}