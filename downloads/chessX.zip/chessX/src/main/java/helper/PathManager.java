
// Funktioniert nicht :(

/*package helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.*;

public class PathManager {

    public static File getFile(String pathInJar) {
        try {
            // Pfad zum Jar-Datei erhalten
            URL jarUrl = PathManager.class.getProtectionDomain().getCodeSource().getLocation();
            String jarFilePath = jarUrl.getPath();

            // Wenn das Jar-Dateiprotokoll vorhanden ist, entferne es
            if (jarFilePath.startsWith("file:")) {
                jarFilePath = jarFilePath.substring("file:".length());
            }

            // Einen temporären Dateipfad erstellen
            Path tempFile = Files.createTempFile("temp", ".jar");

            // Kopiere das Jar-Archiv in die temporäre Datei
            Files.copy(new FileInputStream(jarFilePath), tempFile, StandardCopyOption.REPLACE_EXISTING);

            // FileSystem für das temporäre Jar-Archiv öffnen
            FileSystem fileSystem = FileSystems.newFileSystem(tempFile, null);

            // Pfad innerhalb des Jars zusammenstellen
            String fullPathInJar = "/" + pathInJar;

            // Überprüfen, ob die Datei im Jar vorhanden ist
            Path path = fileSystem.getPath(fullPathInJar);
            if (Files.exists(path)) {
                return path.toFile();
            } else {
                System.err.println("Datei nicht gefunden im Jar: " + fullPathInJar);
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static int countFilesInJarFolder(String folderPathInJar) {
        try {
            String jarFilePath = PathManager.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            FileSystem fileSystem = FileSystems.newFileSystem(Paths.get(jarFilePath), null);
            String fullPathInJar = "/" + folderPathInJar;

            Path folderPath = fileSystem.getPath(fullPathInJar);    // Überprüfen, ob der Ordner im Jar vorhanden ist
            if (!Files.isDirectory(folderPath)) {
                System.err.println("Der angegebene Pfad ist kein Ordner im Jar: " + fullPathInJar);
                return 0;
            }

            int count = 0;  // Zählen der Dateien im Ordner
            try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPath)) {
                for (Path path : directoryStream) {
                    count++;
                }
            }
            return count;
        } catch (URISyntaxException | IOException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
*/