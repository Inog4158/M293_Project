package Server;

import javax.swing.*;
import java.awt.*;
import java.io.Serializable;

public class ScoreBoard implements Serializable {
    private int scoreWhite;
    private int scoreBlack;
    private final JLabel Score;
    private final JLabel Winning;

    public ScoreBoard(JLabel s, JLabel w) {
        scoreWhite = 0;
        scoreBlack = 0;
        Score = s;
        Winning = w;
    }

    public int getScoreBlack() {
        return scoreBlack;
    }

    public int getScoreWhite() {
        return scoreWhite;
    }

    public void setScoreBlack(int scoreBlack) {
        this.scoreBlack = scoreBlack;
    }

    public void setScoreWhite(int scoreWhite) {
        this.scoreWhite = scoreWhite;
    }

    public void addScoreBlack(int scoreBlack) {
        this.scoreBlack += scoreBlack;
    }

    public void addScoreWhite(int scoreWhite) {
        this.scoreWhite += scoreWhite;
    }

    public void updateScore() {
        Score.setText("White: " + scoreWhite + " | Black: " + scoreBlack);
        if (scoreWhite >= scoreBlack) {
            int x = scoreWhite - scoreBlack;
            Winning.setText("{ WHITE +" + x + " }");
        } else {
            int x = scoreBlack - scoreWhite;
            Winning.setText("{ BLACK +" + x + " }");
        }
    }
}
