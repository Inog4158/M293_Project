package Server;

import Buttons.buttonEditor;
import Buttons.buttonMaker;
import Buttons.chessboardButton;
import Cells.CellBoard;
import Client.DesignChooser;
import Controller.Controller;
import Pieces.*;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.*;

public class chessSetup {
    private final JPanel gui;
    private ArrayList<pieceBase> pieceList;
    private final CellBoard cellHolder = new CellBoard();
    private static final String COLS = "ABCDEFGH";
    private pieceKing blackKing;
    private pieceKing whiteKing;
    private JToolBar tools = new JToolBar();
    private String rootPath;

    public chessSetup(String rootPath, ThreadGroup threadGroup) {
        this.rootPath = rootPath;
        gui = new JPanel(new BorderLayout(3, 3));
        JLabel turnLabel = new JLabel("");
        turnLabel.setForeground(Color.BLUE);

        ScoreBoard scoreBoard = createScoreBoard();
        JPanel chessBoard = createChessBoard();
        chessboardButton[][] chessBoardSquares = new chessboardButton[8][8];
        buttonEditor buttonEdit = new buttonEditor(chessBoardSquares);

        makePieces();
        Controller controller = new Controller(scoreBoard, pieceList, cellHolder, blackKing, whiteKing, rootPath, threadGroup);
    }




    private JPanel createChessBoard() {
        gui.setBorder(new EmptyBorder(5, 5, 5, 5));
        JPanel chessBoard = new JPanel(new GridLayout(0, 9));
        chessBoard.setBorder(new LineBorder(Color.BLACK));
        gui.add(chessBoard);
        return chessBoard;
    }

    private ScoreBoard createScoreBoard() {
        JLabel Score = new JLabel();
        JLabel Winning = new JLabel();
        tools.addSeparator();
        tools.addSeparator();
        tools.add(Winning);
        ScoreBoard scoreBoard = new ScoreBoard(Score, Winning);
        scoreBoard.updateScore();
        return scoreBoard;
    }

    private void makePieces() {
        pieceList = new ArrayList<>();
        whiteKing = new pieceKing(cellHolder, rootPath, true);
        pieceList.add(whiteKing);
        blackKing = new pieceKing(cellHolder, rootPath, false);
        pieceList.add(blackKing);
        for (int i = 0; i < 2; i++) {

            pieceRook rook = new pieceRook(cellHolder, rootPath, i == 0);
            pieceList.add(rook);
            rook = new pieceRook(cellHolder, rootPath, i == 0);
            pieceList.add(rook);

            pieceBishop bishop = new pieceBishop(cellHolder, rootPath, i == 0);
            pieceList.add(bishop);
            bishop = new pieceBishop(cellHolder, rootPath, i == 0);
            pieceList.add(bishop);

            pieceQueen queen = new pieceQueen(cellHolder, rootPath, i == 0);
            pieceList.add(queen);

            pieceKnight knight = new pieceKnight(cellHolder, rootPath, i == 0);
            pieceList.add(knight);
            knight = new pieceKnight(cellHolder, rootPath, i == 0);
            pieceList.add(knight);

            for (int ii = 0; ii < 8; ii++) {
                piecePawn pawn = new piecePawn(cellHolder, rootPath, i == 0, pieceList);
                pieceList.add(pawn);
            }
        }
        pieceList.get(0).setCurrentCell(7, 4);//k
        pieceList.get(1).setCurrentCell(0, 4);//k

        pieceList.get(2).setCurrentCell(7, 0);//r
        pieceList.get(3).setCurrentCell(7, 7);//r
        pieceList.get(4).setCurrentCell(7, 2);//b
        pieceList.get(5).setCurrentCell(7, 5);//b
        pieceList.get(6).setCurrentCell(7, 3);//q
        pieceList.get(7).setCurrentCell(7, 1);//s
        pieceList.get(8).setCurrentCell(7, 6);//s
        for (int i = 0; i < 8; i++) {
            pieceList.get(i + 9).setCurrentCell(6, i);
        }


        pieceList.get(17).setCurrentCell(0, 0);//r
        pieceList.get(18).setCurrentCell(0, 7);//r
        pieceList.get(19).setCurrentCell(0, 2);//b
        pieceList.get(20).setCurrentCell(0, 5);//b
        pieceList.get(21).setCurrentCell(0, 3);//q
        pieceList.get(22).setCurrentCell(0, 1);//s
        pieceList.get(23).setCurrentCell(0, 6);//s
        for (int i = 0; i < 8; i++) {
            pieceList.get(i + 24).setCurrentCell(1, i);
        }
    }
}