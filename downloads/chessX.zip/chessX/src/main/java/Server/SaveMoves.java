package Server;

import Cells.Cell;
import Cells.CellBoard;
import Pieces.pieceBase;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class SaveMoves implements Serializable {
    private String notationPosition;
    private String notationName;
    String[] rowToBuchstabe = { "a", "b", "c", "d", "e", "f", "g", "h" };
    String[] colToBuchstabe = { "8", "7", "6", "5", "4", "3", "2", "1" };
    String samePiece;
    transient FileWriter myWriter;
    int counter;
    int moveCounter;
    private String rootPath;
    private String path;

    public SaveMoves(String rootPath) {
        this.rootPath = rootPath;
        path = rootPath+"data\\chessX-safe.csv";
        counter = 0;
        moveCounter = 1;
        setFiletoZero();
    }

    private void setFiletoZero() {
        try {
            myWriter = new FileWriter(path);
            myWriter.write("");
            myWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ChessNotation(int row, int col, pieceBase currentPiece, pieceBase killedPiece, boolean isRochade, ArrayList<pieceBase> pieceList, CellBoard cellHolder, int rowBefore, int colBefore) {
        samePiece(row, col, currentPiece, pieceList, cellHolder, rowBefore, colBefore);
        chessNotationPosition(row, col);
        chessNotationPiece(currentPiece);
        chessNotationWrite(row, col, killedPiece, isRochade);
    }

    private void chessNotationPosition(int row, int col) {
        String[][] piecePositions = new String[][] {
                { "a8", "a7", "a6", "a5", "a4", "a3", "a2", "a1" },
                { "b8", "b7", "b6", "b5", "b4", "b3", "b2", "b1" },
                { "c1", "c7", "c6", "c5", "c4", "c3", "c2", "c1" },
                { "d8", "d7", "d6", "d5", "d4", "d3", "d2", "d1" },
                { "e8", "e7", "e6", "e5", "e4", "e3", "e2", "e1" },
                { "f8", "f7", "f6", "f5", "f4", "f3", "f2", "f1" },
                { "g8", "g7", "g6", "g5", "g4", "g3", "g2", "g1" },
                { "h8", "h7", "h6", "h5", "h4", "h3", "h2", "h1" },
        };
        notationPosition = piecePositions[col][row];
    }

    private void chessNotationPiece(pieceBase piece) {
        switch (piece.getName()) {
            case "queen":
                notationName = "Q";
                break;
            case "rook":
                notationName = "R";
                break;
            case "bishop":
                notationName = "B";
                break;
            case "knight":
                notationName = "N";
                break;
            case "king":
                notationName = "K";
                break;
            case "pawn":
                notationName = "";
                break;
        }
    }

    private void chessNotationWrite(int row, int col, pieceBase killedPiece, boolean isRochade) {
        if (samePiece == null) {
            samePiece = "";
        }

        try {
            myWriter = new FileWriter(path, true);
            myWriter.write("");

            if (counter % 2 == 0) {
                myWriter.write(moveCounter + ". ");
                moveCounter++;
            }
            counter++;

            if (isRochade && col == 6) {
                myWriter.write("o-o");
            } else if (isRochade && col == 2) {
                myWriter.write("o-o-o");
            } else if (killedPiece == null && !isRochade) {
                myWriter.write(notationName + samePiece + notationPosition);
            } else if (killedPiece != null && !isRochade) {
                myWriter.write(notationName + samePiece + "x" + notationPosition);
            }
            myWriter.write("\t");

            if (counter % 2 == 0) {
                myWriter.write("\n");
            }

            myWriter.close();
        } catch (IOException e) {

            e.printStackTrace();
        }

    }

    public void chessNotationChek() {
        // TODO
    }

    public void chessNotationMate() {
        // TODO
    }

    public void samePiece(int row, int col, pieceBase piece, ArrayList<pieceBase> pieceList, CellBoard cellHolder, int rowBefore, int colBefore) {
        for (pieceBase x : pieceList) {
            if (piece.getName().equals(x.getName()) && (x.getIsWhite() == piece.getIsWhite()) && piece != x) {
                x.canMove();
                for (Cell c : x.getAllowedCaptures()) {
                    if (c.getRow() == row && c.getCol() == col) {
                        samePieceSet(c, rowBefore, colBefore);
                    }
                }
                for (Cell c : x.getAllowedMoves()) {
                    if (c.getRow() == row && c.getCol() == col) {
                        samePieceSet(c, rowBefore, colBefore);
                    }
                }
            }
        }
    }

    public void samePieceSet(Cell c, int rowBefore, int colBefore) {
        if (c.getRow() == rowBefore) {
            samePiece = rowToBuchstabe[colBefore];
        } else if (c.getCol() == colBefore) {
            samePiece = colToBuchstabe[rowBefore];
        } else {
            samePiece = rowToBuchstabe[colBefore]; // Buchstabe, mann kann aber auch die zahl nehmen
        }
    }
}
