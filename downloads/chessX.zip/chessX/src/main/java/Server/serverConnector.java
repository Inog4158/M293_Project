package Server;

import Controller.Controller;

import java.io.*;
import java.net.*;
import java.util.*;

public class serverConnector implements Runnable, Serializable {
    transient ArrayList<ObjectOutputStream> clientAusgabeStroeme;
    private Controller controller;
    private Object DATA;
    private transient ThreadGroup threadGroup;

    public serverConnector(Controller co, ThreadGroup threadGroup) {
        controller = co;
        this.threadGroup = threadGroup;
    }

    public class ClientHandler implements Runnable {
        Socket sock;
        ObjectInputStream reader;

        public ClientHandler(Socket clientSocket) {
            try {
                sock = clientSocket;
                reader = new ObjectInputStream(sock.getInputStream());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void run() {
            Object nachricht;
            try {
                while ((nachricht = reader.readObject()) != null) {
                   String cordinate[] = ((String) nachricht).split(":");
                    int row = Integer.parseInt(cordinate[0]);
                    int col = Integer.parseInt(cordinate[1]);
                    if(row < 8 && row > -1 && col < 8 && col > -1) {
                        controller.pressedButton(row, col);
                    }
                    else if(row == -1 && col == -1){
                        esAllenWeitersagen(controller);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }


    public void run() {
        clientAusgabeStroeme = new ArrayList();
        try {
            ServerSocket serverSock = new ServerSocket(5000);
            while (true) {
                Socket clientSocket = serverSock.accept();
                ObjectOutputStream writer = new ObjectOutputStream(clientSocket.getOutputStream());
                clientAusgabeStroeme.add(writer);
                Thread t = new Thread(threadGroup, new ClientHandler(clientSocket));
                t.start();
                System.out.println("habe eine Verbindung");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void esAllenWeitersagen(Object nachricht) {
        byte[] byteData = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(nachricht);
            oos.flush();
            oos.close();
            bos.close();
            byteData = bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
        sendData(byteData);


    }
    private void sendData(Object data){
        Iterator it = clientAusgabeStroeme.iterator();
        while (it.hasNext()) {
            try {
                ObjectOutputStream writer = (ObjectOutputStream) it.next();
                writer.writeObject(data);
                writer.flush();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void uploadController(Controller co) {
        this.controller = co;
        esAllenWeitersagen(controller);
    }

    public void uploadCheckmate(Boolean WhiteLost) {
        sendData(WhiteLost);
        while(true);
    }


}
