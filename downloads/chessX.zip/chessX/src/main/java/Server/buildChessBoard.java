/*package Server;

import Cells.Cell;
import Pieces.pieceBase;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class buildChessBoard {

    private ArrayList<pieceBase> listofAllPieces = new ArrayList<>();
    ArrayList<String> Moves = new ArrayList<>();
    ArrayList<Integer> rows = new ArrayList<>();
    ArrayList<Integer> cols = new ArrayList<>();
    ArrayList<String> names = new ArrayList<>();
    int row;
    int col;


    public buildChessBoard(ArrayList<pieceBase> pieceList) {
        pieceList = listofAllPieces; //warum ist das null?
    }

    public void csvSplit() {
        try {
            File myObj = new File("C:\\git\\chessX\\src\\main\\java\\chessX-safe.csv");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] splitData = data.split(". ");
                String[] ka = splitData[1].split("\t");
                Moves.add(ka[0]); //white's move
                Moves.add(ka[1]); //black's move
            }
            myReader.close();
            if (!Moves.isEmpty()) {
                for (String x : Moves) {
                    System.out.println(x);
                }
                splitIntoRowAndCol();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void splitIntoRowAndCol() {
        //   String[] BuchstabeToCol = { "8", "7", "6", "5", "4", "3", "2", "1" };

        for (String s : Moves) {
            if (s.contains("x")) {
                isaCapture(s);
            } else if (s.contains("-")) {
                isRochade(s);
            } else if (s.contains("Q") || s.contains("R") || s.contains("B") || s.contains("N") || s.contains("K")) {
                isGrossBuchstabe(s);
            } else {
                isNothing(s);
            }
            System.out.println("\n");
        }
    }

    public void isaCapture(String s) {
        String[] ka = s.split("x");
        String[] idk = ka[1].split("");

        row = Integer.parseInt(idk[1]);
        System.out.println("Row: " + row);
        convertToRow(idk[0]);
    }

    public void isRochade(String s) {
        s.split("-");
        System.out.println("rochade");
    }

    public void isGrossBuchstabe(String s) {
        String[] idk = s.split("");

        //idk0 ist der grossbuchstabe
        //bei x die getallowed captures durchgehen
        findCurrentPiece(idk[0]);
        row = Integer.parseInt(idk[2]);
        System.out.println("Row: " + row);

        convertToRow(idk[1]);
    }

    public void isNothing(String s) {
        String[] finalSplit = s.split("");

        row = Integer.parseInt(finalSplit[1]);
        System.out.println("Row: " + row);
        convertToRow(finalSplit[0]);
    }

    public void convertToRow(String b) {
        String[] BuchstabeToRow = { "a", "b", "c", "d", "e", "f", "g", "h" };
        col = 0;

        for (int i = 0; i <= 7; i++) {
            if (BuchstabeToRow[i].equals(b)) {
                System.out.println("Col: " + i);
                col = i;
            }
        }
        idk(row, col);
    }

    public void idk(int row, int col) {
        rows.add(row);
        cols.add(col);
    }

    //current piece anhand vom split wählen und dann mit row und col diesen move ausführen
    public ArrayList<Integer> getRows() {
        return rows;
    }

    public ArrayList<Integer> getCols() {
        return cols;
    }
    public void findCurrentPiece(String ka) {
        switch (ka) {
            case "Q":
                names.add("queen");
                //createCP("queen");
                break;
            case "R":
                names.add("rook");
                //createCP("rook");
                break;
            case "B":
                names.add("bishop");
                //createCP("bishop");
                break;
            case "N":
                names.add("knight");
                //createCP("knight");
                break;
            case "K":
                names.add("king");
                //createCP("king");
                break;
        }
    }

    public ArrayList<String> getNames() {
        return names;
    }
    public void createCP(String name) {
        pieceBase piece;
        for (pieceBase x : listofAllPieces) {
            if (x.getName().equals(name)) {
                piece = x.getCurrentCell().getPiece();
                for (Cell c : piece.getAllowedMoves()) {
                    if (c.getRow() == row && c.getCol() == col) {
                        System.out.println("jaaa gefunden");
                    }
                }
            }
        }
    }
}*/

